import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../providers/base_view_state.dart';
import '../../../data/repositories/product_repository.dart';
import '../../../providers/marketplace_provider.dart';
import '../../../routes/app_router.dart';
import '../../widgets/product_card.dart';
import '../../widgets/shimmer_box.dart';
import '../../widgets/state_views.dart';
import 'filters_sheet.dart';

class MarketplaceScreen extends StatefulWidget {
  const MarketplaceScreen({
    super.key,
    this.initialCategoryId,
    this.initialQuery,
  });

  final String? initialCategoryId;
  final String? initialQuery;

  @override
  State<MarketplaceScreen> createState() => _MarketplaceScreenState();
}

class _MarketplaceScreenState extends State<MarketplaceScreen> {
  final _scroll = ScrollController();
  final _searchCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    _scroll.addListener(_onScroll);
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final provider = context.read<MarketplaceProvider>();
      if (widget.initialQuery != null && widget.initialQuery!.isNotEmpty) {
        _searchCtrl.text = widget.initialQuery!;
        provider.applyFilters(
          provider.filters.copyWith(query: widget.initialQuery),
        );
      } else if (widget.initialCategoryId != null) {
        provider.applyFilters(
          provider.filters.copyWith(categoryId: widget.initialCategoryId),
        );
      } else if (provider.status == ViewStatus.initial) {
        provider.load();
      }
    });
  }

  void _onScroll() {
    // Infinite scrolling: fetch the next page near the end of the list.
    if (_scroll.position.pixels >=
        _scroll.position.maxScrollExtent - 400) {
      context.read<MarketplaceProvider>().loadMore();
    }
  }

  @override
  void dispose() {
    _scroll.removeListener(_onScroll);
    _scroll.dispose();
    _searchCtrl.dispose();
    super.dispose();
  }

  void _submitSearch(String text) {
    final provider = context.read<MarketplaceProvider>();
    final f = provider.filters;
    // copyWith usa `??`, por isso não consegue LIMPAR a query — construímos à mão.
    provider.applyFilters(ProductFilters(
      query: text.trim().isEmpty ? null : text.trim(),
      categoryId: f.categoryId,
      province: f.province,
      district: f.district,
      minPrice: f.minPrice,
      maxPrice: f.maxPrice,
      condition: f.condition,
      sort: f.sort,
    ));
  }

  Future<void> _openFilters() async {
    final provider = context.read<MarketplaceProvider>();
    final result = await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      showDragHandle: true,
      builder: (_) => FiltersSheet(
        current: provider.filters,
        categories: provider.categories,
      ),
    );
    if (result != null) await provider.applyFilters(result);
  }

  @override
  Widget build(BuildContext context) {
    final provider = context.watch<MarketplaceProvider>();
    return Scaffold(
      appBar: AppBar(
        title: const Text('Mercado'),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(60),
          child: Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 10),
            child: SearchBar(
              controller: _searchCtrl,
              hintText: 'Pesquisar produtos…',
              leading: const Icon(Icons.search_rounded),
              elevation: const WidgetStatePropertyAll(0),
              onSubmitted: _submitSearch,
              trailing: [
                if (_searchCtrl.text.isNotEmpty)
                  IconButton(
                    icon: const Icon(Icons.close_rounded),
                    onPressed: () {
                      _searchCtrl.clear();
                      _submitSearch('');
                      setState(() {});
                    },
                  ),
              ],
            ),
          ),
        ),
        actions: [
          IconButton(
            tooltip: provider.isGridView ? 'Ver em lista' : 'Ver em grelha',
            onPressed: provider.toggleLayout,
            icon: Icon(provider.isGridView
                ? Icons.view_list_rounded
                : Icons.grid_view_rounded),
          ),
          IconButton(
            onPressed: _openFilters,
            icon: Badge(
              isLabelVisible: provider.filters.activeCount > 0,
              label: Text('${provider.filters.activeCount}'),
              child: const Icon(Icons.tune_rounded),
            ),
          ),
        ],
      ),
      body: RefreshIndicator(
        onRefresh: () => provider.load(refresh: true),
        child: switch (provider.status) {
          ViewStatus.loading ||
          ViewStatus.initial =>
            const SingleChildScrollView(child: ProductGridShimmer()),
          ViewStatus.error => ErrorStateView(
              message: provider.error ?? '',
              onRetry: () => provider.load(),
            ),
          ViewStatus.empty => EmptyStateView(
              icon: Icons.storefront_outlined,
              title: 'Nenhum produto encontrado',
              message:
                  'Ajuste os filtros ou volte mais tarde — novos anúncios são publicados todos os dias.',
              actionLabel: provider.filters.isEmpty ? null : 'Limpar filtros',
              onAction: provider.filters.isEmpty
                  ? null
                  : () => provider
                      .applyFilters(const ProductFilters()),
            ),
          _ => provider.isGridView
              ? GridView.builder(
                  controller: _scroll,
                  physics: const AlwaysScrollableScrollPhysics(),
                  padding: const EdgeInsets.all(16),
                  gridDelegate:
                      const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2,
                    mainAxisSpacing: 12,
                    crossAxisSpacing: 12,
                    childAspectRatio: .72,
                  ),
                  itemCount: provider.products.length +
                      (provider.status.isLoadingMore ? 2 : 0),
                  itemBuilder: (_, i) {
                    if (i >= provider.products.length) {
                      return const ShimmerBox(
                          height: double.infinity, radius: 16);
                    }
                    final p = provider.products[i];
                    return ProductCard(
                      product: p,
                      onTap: () => Navigator.pushNamed(
                        context,
                        AppRouter.productDetail,
                        arguments: p.id,
                      ),
                    );
                  },
                )
              : ListView.separated(
                  controller: _scroll,
                  physics: const AlwaysScrollableScrollPhysics(),
                  padding: const EdgeInsets.all(16),
                  itemCount: provider.products.length +
                      (provider.status.isLoadingMore ? 1 : 0),
                  separatorBuilder: (_, __) => const SizedBox(height: 12),
                  itemBuilder: (_, i) {
                    if (i >= provider.products.length) {
                      return const ShimmerBox(height: 110, radius: 16);
                    }
                    final p = provider.products[i];
                    return ProductListTile(
                      product: p,
                      onTap: () => Navigator.pushNamed(
                        context,
                        AppRouter.productDetail,
                        arguments: p.id,
                      ),
                    );
                  },
                ),
        },
      ),
    );
  }
}

