# 🌱 AgroMoz API — integrada com o site existente

REST API em **PHP puro** que serve a app Flutter usando a **mesma base de dados do site agromoz.com**: mesmos utilizadores (mesmo login!), mesmos produtos, mesmas empresas e categorias. Sem frameworks, sem Composer.

**Requisitos**: PHP 8.0+ (cPanel → *Select PHP Version*).

---

## 🔗 Como o site e a app se ligam

| Conceito na app | Tabela do site |
|---|---|
| Login / conta do utilizador | `users` (senhas bcrypt — 100% compatível) |
| Produtos do marketplace | `produtos` (só `status='ativo'` de empresas activas) |
| Vendedor / perfil de agricultor | `empresas` (nome, logo, província, contactos) |
| Categorias | `categorias_negocio` |
| Recuperar senha (OTP) | colunas `verification_code`/`verification_expires` de `users` |
| Chat, favoritos, avaliações, notificações, sessões, banners | tabelas NOVAS `app_*` (não mexem em nada) |

O chat da app com um vendedor liga o comprador ao **dono da empresa** (`empresas.user_id`).

## 🚀 Instalação (4 passos)

### 1. Importar as tabelas novas
phpMyAdmin → seleccione a **base de dados do site** → Importar → `schema-app.sql`. Cria 8 tabelas `app_*` com foreign keys para `users`, `produtos` e `empresas`. **Não altera nenhuma tabela existente.**

### 2. Carregar os ficheiros
File Manager → `public_html` → extraia a pasta **`appapi/`** (fica ao lado da sua pasta `api/` actual, sem lhe tocar). Dê permissão 755 a `appapi/uploads/`.

### 3. Configurar
Renomeie `config.sample.php` → `config.php` e preencha `DB_NAME`, `DB_USER`, `DB_PASS` com os dados **da base de dados do site**. Confirme `BASE_URL` e `SITE_URL`.

### 4. Testar
- `https://agromoz.com/appapi/v1/categories` → deve listar as suas categorias (Milho, Tomate, Coelhos…)
- `https://agromoz.com/appapi/v1/products` → deve listar o milho e o feijão da Machamba Mavudzi
- Login na app com **qualquer conta do site** (ex.: a sua conta admin) → funciona

Depois, no Flutter: `baseUrl = 'https://agromoz.com/appapi/v1'` e recompilar o APK.

## 🆕 Novo na v2 (Julho 2026)
- **Verificação de conta por e-mail** (igual ao site): `/register` cria a conta por verificar e envia o código de 6 dígitos (reutiliza `includes/mailer.php` do site; fallback `mail()`); `/verify-email` confirma e devolve tokens; `/resend-code` reenvia; o `/login` de conta por confirmar devolve 403 com `needs_verification`.
- **Artigos**: `/articles` (paginado, `?category_id`, `?q`), `/articles/{slug}` (conteúdo completo p/ ler dentro da app), `/articles/categories`.
- **Fluxo profissional**: `GET|POST /business` (criar empresa multipart c/ logo*, cover, gallery[] → status `pendente`), `POST /business/update`, `GET /business/stats`, `GET /business/types`, `GET|POST /business/products`, `POST /business/products/{id}`, `PATCH /business/products/{id}/availability`. Escreve nas tabelas do site (`empresas`, `empresa_categorias`, `empresa_imagens`, `produtos`); a aprovação continua no painel admin.
- **Avaliações**: `POST /farmers/{id}/reviews` {rating 1-5, comment} — uma por utilizador (repetir actualiza) + notificação in-app ao dono.
- `/categories?type=agricultor` filtra categorias por tipo de perfil (detecta a coluna/pivot automaticamente; devolve todas se não existir).
- `/verify-otp` aceita agora `new_password` opcional para completar o "esqueci a senha" num só passo.

## 📡 Endpoints
Mesma tabela de rotas da versão anterior (`/v1/login`, `/v1/products` com filtros e paginação, `/v1/farmers/{id}`, `/v1/messages`, `/v1/notifications`, `/v1/search`…). Notas específicas da integração:

- **Filtro de província**: o site guarda variações ("Maputo", "Maputo província"); a API compara pela primeira palavra, sem maiúsculas.
- **Filtro "estado" (novo/usado)**: o site não tem essa coluna — o parâmetro é aceite e ignorado.
- **`/v1/banners`**: lê `app_banners`; insira os banners do carrossel no phpMyAdmin (há um exemplo comentado no schema-app.sql). `image_url` aceita caminho relativo do site.
- **Registo pela app**: cria o utilizador em `users` (status active). Para *vender*, o utilizador cria a empresa no site — fluxo que já tem.
- **Imagens**: caminhos relativos (`uploads/...`) são convertidos para URLs completos via `SITE_URL`.

## 🔒 Segurança
Prepared statements em tudo; bcrypt (`password_verify`) compatível com o site; tokens de 64 chars com expiração e rotação de refresh; contas `banned`/`inactive` bloqueadas; uploads validados e pasta sem execução PHP; `config.php` e `.sql` bloqueados no `.htaccess`.

## 📌 Ganchos prontos
- **Envio do OTP**: `routes/auth.php` → `route_forgot_password()` tem o TODO para ligar o e-mail/SMS (pode reutilizar o mecanismo de verificação do site). Enquanto testa, `DEBUG_OTP=true` devolve o código na resposta — **desligue em produção**.
- **Push FCM**: tokens em `app_device_tokens`; ao criar `app_notifications`, envie o push para esses tokens.
- **Avaliações**: a tabela `app_reviews` está pronta; se quiser que a app permita avaliar empresas, acrescenta-se uma rota POST em 10 linhas.
