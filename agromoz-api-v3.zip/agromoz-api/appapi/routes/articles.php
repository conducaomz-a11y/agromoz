<?php
/** Artigos educativos — tabelas articles + categories do site.
 *  A app mostra a lista e ABRE o artigo dentro da app (conteúdo completo). */

/** GET /articles?page=&per_page=&category_id=&q= */
function route_articles(): void {
    $page    = max(1, (int)($_GET['page'] ?? 1));
    $perPage = min(30, max(1, (int)($_GET['per_page'] ?? 10)));

    $where = ["a.status = 'published'"];
    $args  = [];
    if (!empty($_GET['category_id'])) { $where[] = 'a.category_id = ?'; $args[] = $_GET['category_id']; }
    if (!empty($_GET['q'])) {
        $where[] = '(a.title LIKE ? OR a.excerpt LIKE ?)';
        $like = '%' . $_GET['q'] . '%';
        array_push($args, $like, $like);
    }
    $whereSql = 'WHERE ' . implode(' AND ', $where);

    $pdo = db();
    $count = $pdo->prepare("SELECT COUNT(*) FROM articles a $whereSql");
    $count->execute($args);
    $total = (int)$count->fetchColumn();

    $offset = ($page - 1) * $perPage;
    $q = $pdo->prepare(
        "SELECT a.*, c.name AS category_name
         FROM articles a LEFT JOIN categories c ON c.id = a.category_id
         $whereSql ORDER BY a.published_at DESC LIMIT $perPage OFFSET $offset"
    );
    $q->execute($args);

    json_paginated(
        array_map('article_summary_json', $q->fetchAll()),
        $page,
        (int)ceil($total / $perPage)
    );
}

/** GET /articles/{slugOuId} — artigo completo (para abrir DENTRO da app). */
function route_article_detail(string $slug): void {
    $q = db()->prepare(
        "SELECT a.*, c.name AS category_name
         FROM articles a LEFT JOIN categories c ON c.id = a.category_id
         WHERE (a.slug = ? OR a.id = ?) AND a.status = 'published' LIMIT 1"
    );
    $q->execute([$slug, $slug]);
    $a = $q->fetch();
    if (!$a) json_error('Artigo não encontrado.', 404);

    $json = article_summary_json($a);
    // Conteúdo completo (o nome da coluna varia entre instalações — cobre os comuns).
    $json['content'] = $a['content'] ?? ($a['body'] ?? ($a['conteudo'] ?? ''));
    json_out(['data' => $json]);
}

/** GET /articles/categories — categorias de artigos com contagem. */
function route_article_categories(): void {
    $q = db()->query(
        "SELECT c.id, c.name, COUNT(a.id) AS article_count
         FROM categories c
         LEFT JOIN articles a ON a.category_id = c.id AND a.status = 'published'
         GROUP BY c.id, c.name
         HAVING article_count > 0
         ORDER BY c.name"
    );
    json_list(array_map(fn($c) => [
        'id' => (string)$c['id'],
        'name' => $c['name'],
        'article_count' => (int)$c['article_count'],
    ], $q->fetchAll()));
}

function article_summary_json(array $a): array {
    // imagem de capa: cobre nomes de coluna comuns
    $img = $a['image'] ?? ($a['cover'] ?? ($a['imagem'] ?? ($a['featured_image'] ?? null)));
    return [
        'id'            => (string)$a['id'],
        'title'         => $a['title'],
        'slug'          => $a['slug'],
        'excerpt'       => $a['excerpt'] ?? null,
        'image_url'     => site_url($img),
        'category_id'   => isset($a['category_id']) ? (string)$a['category_id'] : null,
        'category_name' => $a['category_name'] ?? null,
        'published_at'  => $a['published_at'] ?? null,
    ];
}
