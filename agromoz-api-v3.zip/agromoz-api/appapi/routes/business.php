<?php
/** Fluxo PROFISSIONAL — replica o /profissional/ do site dentro da app.
 *  Mesmas tabelas: empresas, empresa_categorias, empresa_imagens, produtos,
 *  categorias_negocio. Empresa nova entra 'pendente' (aprovação no painel admin). */

// ── Tipos de perfil (mesmos do site) ─────────────────────────────
function business_types(): array {
    return [
        'agricultor'       => ['label' => 'Agricultor',            'icon' => 'sprout'],
        'horticultor'      => ['label' => 'Horticultor',           'icon' => 'leaf'],
        'avicultor'        => ['label' => 'Avicultor',             'icon' => 'bird'],
        'cunicultor'       => ['label' => 'Cunicultor',            'icon' => 'rabbit'],
        'vendedor_insumos' => ['label' => 'Fornecedor de Insumos', 'icon' => 'store'],
    ];
}

/** GET /business/types */
function route_business_types(): void {
    $out = [];
    foreach (business_types() as $key => $t) {
        $out[] = ['key' => $key, 'label' => $t['label'], 'icon' => $t['icon']];
    }
    json_list($out);
}

/** A empresa do utilizador autenticado (ou null). */
function my_business(int $userId): ?array {
    $q = db()->prepare('SELECT * FROM empresas WHERE user_id = ? LIMIT 1');
    $q->execute([$userId]);
    return $q->fetch() ?: null;
}

function business_json(array $e): array {
    $pdo = db();
    $cats = $pdo->prepare(
        'SELECT c.id, c.nome FROM empresa_categorias ec
         JOIN categorias_negocio c ON c.id = ec.categoria_id WHERE ec.empresa_id = ?'
    );
    $cats->execute([$e['id']]);

    return [
        'id'           => (string)$e['id'],
        'name'         => $e['nome_empresa'],
        'slug'         => $e['slug'] ?? null,
        'type'         => $e['tipo_perfil'],
        'type_label'   => business_types()[$e['tipo_perfil']]['label'] ?? $e['tipo_perfil'],
        'description'  => $e['descricao'],
        'province'     => $e['provincia'],
        'district'     => $e['distrito'],
        'address'      => $e['endereco'] ?? null,
        'latitude'     => isset($e['latitude']) ? (float)$e['latitude'] : null,
        'longitude'    => isset($e['longitude']) ? (float)$e['longitude'] : null,
        'phone'        => $e['telefone'] ?: null,
        'whatsapp'     => $e['whatsapp'] ?: null,
        'email'        => $e['email_contacto'] ?: null,
        'website'      => $e['website'] ?? null,
        'hours'        => $e['horario'] ?? null,
        'logo_url'     => site_url($e['logo'] ?? null),
        'cover_url'    => site_url($e['imagem_capa'] ?? null),
        'status'       => $e['status'],          // pendente | ativo | ...
        'views'        => (int)($e['views'] ?? 0),
        'categories'   => array_map(
            fn($c) => ['id' => (string)$c['id'], 'name' => $c['nome']],
            $cats->fetchAll()
        ),
    ];
}

/** GET /business — a minha empresa (404 se ainda não criou). */
function route_business_get(): void {
    $user = require_auth();
    $e = my_business((int)$user['id']);
    if (!$e) json_error('Ainda não criaste a tua página de negócio.', 404);
    json_out(['data' => business_json($e)]);
}

/** POST /business — criar empresa (multipart: logo*, cover, gallery[]).
 *  Campos: type*, name*, description*, categories (CSV de ids)*, province,
 *  district, address, latitude*, longitude*, phone, whatsapp, email, website, hours. */
function route_business_create(): void {
    $user = require_auth();
    if (my_business((int)$user['id'])) {
        json_error('Já tens uma página de negócio — usa a edição.', 422);
    }

    $type = (string)field('type');
    $name = trim((string)field('name'));
    $desc = trim((string)field('description'));
    $cats = array_filter(array_map('intval', explode(',', (string)field('categories'))));
    $lat  = field('latitude');
    $lng  = field('longitude');

    if (!array_key_exists($type, business_types())) json_error('Escolhe um tipo de perfil válido.', 422);
    if (mb_strlen($name) < 3)  json_error('O nome tem de ter pelo menos 3 caracteres.', 422);
    if (mb_strlen($desc) < 20) json_error('A descrição tem de ter pelo menos 20 caracteres — explica bem o teu negócio.', 422);
    if (!$cats)                json_error('Escolhe pelo menos uma categoria.', 422);
    if ($lat === null || $lng === null) json_error('Marca a localização do negócio.', 422);
    if (empty($_FILES['logo']['tmp_name'])) json_error('Envia uma imagem/logo do teu negócio.', 422);

    $pdo = db();
    $pdo->beginTransaction();
    try {
        $slug  = unique_slug('empresas', $name);
        $logo  = save_upload('logo');
        $cover = save_upload('cover');

        $q = $pdo->prepare(
            'INSERT INTO empresas
             (user_id, tipo_perfil, nome_empresa, slug, descricao, provincia, distrito, endereco,
              latitude, longitude, telefone, whatsapp, email_contacto, website, horario,
              logo, imagem_capa, status)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, "pendente")'
        );
        $q->execute([
            $user['id'], $type, $name, $slug, $desc,
            field('province'), field('district'), field('address'),
            $lat, $lng, field('phone'), field('whatsapp'),
            field('email'), field('website'), field('hours'),
            $logo, $cover,
        ]);
        $empresaId = (int)$pdo->lastInsertId();

        $qc = $pdo->prepare('INSERT INTO empresa_categorias (empresa_id, categoria_id) VALUES (?, ?)');
        foreach ($cats as $catId) $qc->execute([$empresaId, $catId]);

        // Galeria (gallery[] no multipart)
        save_gallery($empresaId);

        $pdo->commit();
    } catch (Throwable $e) {
        $pdo->rollBack();
        throw $e;
    }

    json_out([
        'message' => 'A tua página foi criada e está em revisão. Assim que for aprovada, fica visível ao público.',
        'data' => business_json(my_business((int)$user['id'])),
    ], 201);
}

/** POST /business/update — editar (mesmos campos, todos opcionais). */
function route_business_update(): void {
    $user = require_auth();
    $e = my_business((int)$user['id']);
    if (!$e) json_error('Ainda não criaste a tua página de negócio.', 404);

    $map = [ // campo API → coluna
        'name' => 'nome_empresa', 'description' => 'descricao', 'province' => 'provincia',
        'district' => 'distrito', 'address' => 'endereco', 'latitude' => 'latitude',
        'longitude' => 'longitude', 'phone' => 'telefone', 'whatsapp' => 'whatsapp',
        'email' => 'email_contacto', 'website' => 'website', 'hours' => 'horario',
    ];
    $sets = []; $args = [];
    foreach ($map as $f => $col) {
        $v = field($f, '__missing__');
        if ($v !== '__missing__') { $sets[] = "`$col` = ?"; $args[] = $v; }
    }
    if ($logo  = save_upload('logo'))  { $sets[] = 'logo = ?';        $args[] = $logo; }
    if ($cover = save_upload('cover')) { $sets[] = 'imagem_capa = ?'; $args[] = $cover; }

    if ($sets) {
        $args[] = $e['id'];
        db()->prepare('UPDATE empresas SET ' . implode(', ', $sets) . ' WHERE id = ?')->execute($args);
    }

    $cats = field('categories');
    if ($cats !== null) {
        $ids = array_filter(array_map('intval', explode(',', (string)$cats)));
        if ($ids) {
            db()->prepare('DELETE FROM empresa_categorias WHERE empresa_id = ?')->execute([$e['id']]);
            $qc = db()->prepare('INSERT INTO empresa_categorias (empresa_id, categoria_id) VALUES (?, ?)');
            foreach ($ids as $id) $qc->execute([$e['id'], $id]);
        }
    }
    save_gallery((int)$e['id']);

    json_out(['data' => business_json(my_business((int)$user['id']))]);
}

/** GET /business/stats — cartões do dashboard (iguais ao site). */
function route_business_stats(): void {
    $user = require_auth();
    $e = my_business((int)$user['id']);
    if (!$e) json_error('Ainda não criaste a tua página de negócio.', 404);

    $q = db()->prepare(
        "SELECT
           COUNT(*) AS total,
           SUM(disponibilidade = 'disponivel')   AS available,
           SUM(disponibilidade = 'esgotando')    AS running_out,
           SUM(disponibilidade = 'indisponivel') AS unavailable
         FROM produtos WHERE empresa_id = ?"
    );
    $q->execute([$e['id']]);
    $s = $q->fetch();

    json_out(['data' => [
        'business'      => business_json($e),
        'total_products'=> (int)$s['total'],
        'available'     => (int)$s['available'],
        'running_out'   => (int)$s['running_out'],
        'unavailable'   => (int)$s['unavailable'],
        'page_views'    => (int)($e['views'] ?? 0),
    ]]);
}

// ═════════════════════ PRODUTOS DA MINHA EMPRESA ═════════════════

/** GET /business/products — todos os meus produtos (qualquer estado). */
function route_business_products(): void {
    $user = require_auth();
    $e = my_business((int)$user['id']);
    if (!$e) json_error('Ainda não criaste a tua página de negócio.', 404);

    $q = db()->prepare(
        'SELECT p.*, cn.nome AS category_name
         FROM produtos p LEFT JOIN categorias_negocio cn ON cn.id = p.categoria_id
         WHERE p.empresa_id = ? ORDER BY p.created_at DESC'
    );
    $q->execute([$e['id']]);
    json_list(array_map('own_product_json', $q->fetchAll()));
}

/** POST /business/products — criar produto (multipart "image" opcional). */
function route_business_product_create(): void {
    [$user, $e] = require_business();
    $data = validate_product_input();

    $slug = unique_slug('produtos', $data['nome']);
    $img  = save_upload('image');

    db()->prepare(
        'INSERT INTO produtos
         (empresa_id, categoria_id, nome, slug, descricao, preco, unidade,
          disponibilidade, destaque, imagem, status)
         VALUES (?,?,?,?,?,?,?,?,?,?, "ativo")'
    )->execute([
        $e['id'], $data['categoria_id'], $data['nome'], $slug, $data['descricao'],
        $data['preco'], $data['unidade'], $data['disponibilidade'], $data['destaque'], $img,
    ]);

    $id = (int)db()->lastInsertId();
    json_out(['message' => 'Produto guardado com sucesso.', 'data' => fetch_own_product($id)], 201);
}

/** POST /business/products/{id} — editar produto. */
function route_business_product_update(string $id): void {
    [$user, $e] = require_business();
    $q = db()->prepare('SELECT * FROM produtos WHERE id = ? AND empresa_id = ?');
    $q->execute([$id, $e['id']]);
    $p = $q->fetch();
    if (!$p) json_error('Produto não encontrado.', 404);

    $data = validate_product_input();
    $slug = unique_slug('produtos', $data['nome'], (int)$id);
    $img  = save_upload('image') ?: $p['imagem'];

    db()->prepare(
        'UPDATE produtos SET nome=?, slug=?, categoria_id=?, descricao=?, preco=?,
                unidade=?, disponibilidade=?, destaque=?, imagem=?
         WHERE id = ? AND empresa_id = ?'
    )->execute([
        $data['nome'], $slug, $data['categoria_id'], $data['descricao'], $data['preco'],
        $data['unidade'], $data['disponibilidade'], $data['destaque'], $img,
        $id, $e['id'],
    ]);

    json_out(['message' => 'Produto guardado com sucesso.', 'data' => fetch_own_product((int)$id)]);
}

/** PATCH /business/products/{id}/availability {disponibilidade} */
function route_business_product_availability(string $id): void {
    [$user, $e] = require_business();
    $disp = (string)field('availability', (string)field('disponibilidade'));
    if (!in_array($disp, ['disponivel', 'esgotando', 'indisponivel'], true)) {
        json_error('Disponibilidade inválida.', 422);
    }
    db()->prepare('UPDATE produtos SET disponibilidade = ? WHERE id = ? AND empresa_id = ?')
        ->execute([$disp, $id, $e['id']]);
    json_out(['message' => 'Disponibilidade actualizada.', 'data' => fetch_own_product((int)$id)]);
}

// ── helpers internos ─────────────────────────────────────────────

function require_business(): array {
    $user = require_auth();
    $e = my_business((int)$user['id']);
    if (!$e) json_error('Cria primeiro a tua página de negócio.', 403);
    return [$user, $e];
}

function validate_product_input(): array {
    $nome = trim((string)field('name'));
    if (mb_strlen($nome) < 2) json_error('O nome do produto é obrigatório.', 422);

    $disp = (string)field('availability', 'disponivel');
    if (!in_array($disp, ['disponivel', 'esgotando', 'indisponivel'], true)) {
        json_error('Disponibilidade inválida.', 422);
    }
    $precoRaw = field('price');
    $preco = ($precoRaw !== null && $precoRaw !== '')
        ? (float)str_replace(',', '.', (string)$precoRaw)
        : null; // null → "sob consulta", igual ao site

    return [
        'nome'            => $nome,
        'categoria_id'    => field('category_id') ?: null,
        'descricao'       => trim((string)field('description')),
        'preco'           => $preco,
        'unidade'         => trim((string)field('unit')),
        'disponibilidade' => $disp,
        'destaque'        => (int)(bool)field('featured', false),
    ];
}

function fetch_own_product(int $id): array {
    $q = db()->prepare(
        'SELECT p.*, cn.nome AS category_name
         FROM produtos p LEFT JOIN categorias_negocio cn ON cn.id = p.categoria_id
         WHERE p.id = ?'
    );
    $q->execute([$id]);
    return own_product_json($q->fetch());
}

/** JSON de um produto na óptica do DONO (inclui disponibilidade/destaque/status). */
function own_product_json(array $p): array {
    $img = site_url($p['imagem'] ?? null);
    return [
        'id'            => (string)$p['id'],
        'title'         => $p['nome'],
        'price'         => $p['preco'] !== null ? (float)$p['preco'] : null, // null = sob consulta
        'description'   => $p['descricao'] ?? null,
        'images'        => $img ? [$img] : [],
        'category_id'   => isset($p['categoria_id']) ? (string)$p['categoria_id'] : null,
        'category_name' => $p['category_name'] ?? null,
        'unit'          => $p['unidade'] ?? null,
        'availability'  => $p['disponibilidade'] ?? 'disponivel',
        'is_featured'   => (bool)($p['destaque'] ?? 0),
        'status'        => $p['status'] ?? 'ativo',
        'views'         => (int)($p['views'] ?? 0),
        'created_at'    => $p['created_at'] ?? null,
    ];
}

/** Galeria multipart gallery[] → empresa_imagens. */
function save_gallery(int $empresaId): void {
    if (empty($_FILES['gallery']['tmp_name'][0])) return;
    $ord = (int)db()->query("SELECT COALESCE(MAX(ordem),0) FROM empresa_imagens WHERE empresa_id = $empresaId")->fetchColumn();
    $q = db()->prepare('INSERT INTO empresa_imagens (empresa_id, caminho, ordem) VALUES (?, ?, ?)');
    foreach ($_FILES['gallery']['tmp_name'] as $i => $tmp) {
        if (empty($tmp)) continue;
        $file = [
            'tmp_name' => $tmp,
            'error'    => $_FILES['gallery']['error'][$i],
            'size'     => $_FILES['gallery']['size'][$i],
        ];
        $url = save_upload_array($file);
        if ($url) $q->execute([$empresaId, $url, ++$ord]);
    }
}
