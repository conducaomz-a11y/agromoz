<?php
/** Chat 1-para-1 entre utilizadores do site (tabelas app_).
 *  A app pede /messages/seller_{empresaId}: a API resolve o DONO
 *  da empresa (empresas.user_id) e encontra/cria a conversa. */

function conversation_id_for(string $rawId, int $me): int {
    $pdo = db();
    if (str_starts_with($rawId, 'seller_')) {
        $empresaId = (int)substr($rawId, 7);
        $q = $pdo->prepare('SELECT user_id FROM empresas WHERE id = ?');
        $q->execute([$empresaId]);
        $other = (int)$q->fetchColumn();
        if (!$other) json_error('Vendedor não encontrado.', 404);
        if ($other === $me) json_error('Não pode conversar consigo mesmo.', 422);

        $a = min($me, $other);
        $b = max($me, $other);
        $q = $pdo->prepare('SELECT id FROM app_conversations WHERE user_a = ? AND user_b = ?');
        $q->execute([$a, $b]);
        $id = $q->fetchColumn();
        if ($id) return (int)$id;
        $pdo->prepare('INSERT INTO app_conversations (user_a, user_b) VALUES (?, ?)')->execute([$a, $b]);
        return (int)$pdo->lastInsertId();
    }
    $q = $pdo->prepare('SELECT id FROM app_conversations WHERE id = ? AND (user_a = ? OR user_b = ?)');
    $q->execute([$rawId, $me, $me]);
    $id = $q->fetchColumn();
    if (!$id) json_error('Conversa não encontrada.', 404);
    return (int)$id;
}

/** Utilizador do site como "other_user" do chat. */
function chat_user_json(array $u): array {
    // Se o utilizador tem empresa, mostra o nome/logo da empresa na conversa.
    $q = db()->prepare('SELECT nome_empresa, logo FROM empresas WHERE user_id = ? LIMIT 1');
    $q->execute([$u['id']]);
    $e = $q->fetch();
    return [
        'id'            => (string)$u['id'],
        'name'          => $e['nome_empresa'] ?? $u['name'],
        'email'         => null,
        'phone'         => $u['phone'] ?? null,
        'avatar_url'    => site_url($e['logo'] ?? $u['avatar'] ?? null),
        'province'      => $u['province'] ?? null,
        'district'      => $u['district'] ?? null,
        'bio'           => null,
        'role'          => 'farmer',
        'rating'        => 0,
        'review_count'  => 0,
        'product_count' => 0,
        'is_online'     => false,
        'member_since'  => $u['created_at'] ?? null,
    ];
}

/** GET /messages */
function route_conversations(): void {
    $user = require_auth();
    $me = (int)$user['id'];
    $q = db()->prepare(
        'SELECT c.*,
            (SELECT COALESCE(m.text, "📷 Imagem") FROM app_messages m
             WHERE m.conversation_id = c.id ORDER BY m.id DESC LIMIT 1) AS last_message,
            (SELECT m.created_at FROM app_messages m
             WHERE m.conversation_id = c.id ORDER BY m.id DESC LIMIT 1) AS last_message_at,
            (SELECT COUNT(*) FROM app_messages m
             WHERE m.conversation_id = c.id AND m.sender_id <> ? AND m.is_read = 0) AS unread_count
         FROM app_conversations c
         WHERE c.user_a = ? OR c.user_b = ?
         ORDER BY last_message_at DESC'
    );
    $q->execute([$me, $me, $me]);
    $pdo = db();
    $items = [];
    foreach ($q->fetchAll() as $c) {
        $otherId = ((int)$c['user_a'] === $me) ? $c['user_b'] : $c['user_a'];
        $u = $pdo->prepare('SELECT * FROM users WHERE id = ?');
        $u->execute([$otherId]);
        $other = $u->fetch();
        if (!$other) continue;
        $items[] = [
            'id' => (string)$c['id'],
            'other_user' => chat_user_json($other),
            'last_message' => $c['last_message'],
            'last_message_at' => $c['last_message_at'],
            'unread_count' => (int)$c['unread_count'],
        ];
    }
    json_list($items);
}

/** GET /messages/{id} */
function route_messages(string $rawId): void {
    $user = require_auth();
    $me = (int)$user['id'];
    $convId = conversation_id_for($rawId, $me);

    $pdo = db();
    $pdo->prepare('UPDATE app_messages SET is_read = 1 WHERE conversation_id = ? AND sender_id <> ?')
        ->execute([$convId, $me]);

    $q = $pdo->prepare('SELECT * FROM app_messages WHERE conversation_id = ? ORDER BY id ASC');
    $q->execute([$convId]);
    json_list(array_map(fn($m) => message_json($m), $q->fetchAll()));
}

/** POST /messages/{id} — texto (JSON {text}) ou imagem (multipart "image"). */
function route_message_send(string $rawId): void {
    $user = require_auth();
    $me = (int)$user['id'];
    $convId = conversation_id_for($rawId, $me);

    $imageUrl = save_upload('image');
    $text = trim((string)field('text', ''));
    if ($imageUrl === null && $text === '') json_error('Mensagem vazia.', 422);

    $pdo = db();
    $pdo->prepare(
        'INSERT INTO app_messages (conversation_id, sender_id, text, image_url) VALUES (?,?,?,?)'
    )->execute([$convId, $me, $text !== '' ? $text : null, $imageUrl]);

    $q = $pdo->prepare('SELECT * FROM app_messages WHERE id = ?');
    $q->execute([$pdo->lastInsertId()]);
    json_out(['data' => message_json($q->fetch())], 201);
}

function message_json(array $m): array {
    return [
        'id' => (string)$m['id'],
        'sender_id' => (string)$m['sender_id'],
        'text' => $m['text'],
        'image_url' => $m['image_url'],
        'sent_at' => $m['created_at'],
        'is_read' => (bool)$m['is_read'],
    ];
}
