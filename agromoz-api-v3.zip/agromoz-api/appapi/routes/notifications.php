<?php
/** Notificações da app (app_notifications) + tokens FCM (app_device_tokens). */

function route_notifications(): void {
    $user = require_auth();
    $q = db()->prepare('SELECT * FROM app_notifications WHERE user_id = ? ORDER BY id DESC LIMIT 100');
    $q->execute([$user['id']]);
    json_list(array_map(fn($n) => [
        'id' => (string)$n['id'],
        'title' => $n['title'],
        'body' => $n['body'],
        'type' => $n['type'],
        'is_read' => (bool)$n['is_read'],
        'created_at' => $n['created_at'],
        'target_id' => $n['target_id'] !== null ? (string)$n['target_id'] : null,
    ], $q->fetchAll()));
}

function route_notification_read(string $id): void {
    $user = require_auth();
    db()->prepare('UPDATE app_notifications SET is_read = 1 WHERE id = ? AND user_id = ?')
        ->execute([$id, $user['id']]);
    json_out(['message' => 'OK']);
}

function route_notifications_read_all(): void {
    $user = require_auth();
    db()->prepare('UPDATE app_notifications SET is_read = 1 WHERE user_id = ?')
        ->execute([$user['id']]);
    json_out(['message' => 'OK']);
}

function route_register_device(): void {
    $user = require_auth();
    $token = (string)field('token');
    if ($token === '') json_error('Token em falta.', 422);
    db()->prepare(
        'INSERT INTO app_device_tokens (user_id, token, platform) VALUES (?,?,?)
         ON DUPLICATE KEY UPDATE user_id = VALUES(user_id), platform = VALUES(platform)'
    )->execute([$user['id'], $token, field('platform', 'mobile')]);
    json_out(['message' => 'Dispositivo registado.']);
}
