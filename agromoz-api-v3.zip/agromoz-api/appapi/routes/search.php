<?php
/** Pesquisa global: produtos + empresas + categorias_negocio. */

function route_search(): void {
    $viewer = optional_auth();
    $q = trim((string)($_GET['q'] ?? ''));
    if ($q === '') json_out(['products' => [], 'farmers' => [], 'companies' => [], 'categories' => []]);
    $like = '%' . $q . '%';
    $pdo = db();

    $p = $pdo->prepare(
        PRODUCT_SELECT . ' WHERE ' . PUBLIC_WHERE .
        ' AND (p.nome LIKE ? OR p.descricao LIKE ?) ORDER BY p.created_at DESC LIMIT 20'
    );
    $p->execute([$like, $like]);
    $products = array_map(fn($row) => product_json($row, $viewer ? (int)$viewer['id'] : null), $p->fetchAll());

    $e = $pdo->prepare(
        "SELECT * FROM empresas WHERE status = 'ativo' AND (nome_empresa LIKE ? OR descricao LIKE ?) LIMIT 20"
    );
    $e->execute([$like, $like]);
    $farmers = [];
    $companies = [];
    foreach ($e->fetchAll() as $row) {
        $json = empresa_json($row);
        if ($row['tipo_perfil'] === 'vendedor_insumos') $companies[] = $json; else $farmers[] = $json;
    }

    $c = $pdo->prepare('SELECT * FROM categorias_negocio WHERE nome LIKE ? LIMIT 10');
    $c->execute([$like]);
    $categories = array_map(fn($row) => [
        'id' => (string)$row['id'], 'name' => $row['nome'],
        'icon_url' => null, 'product_count' => 0,
    ], $c->fetchAll());

    json_out(compact('products', 'farmers', 'companies', 'categories'));
}

function route_search_suggestions(): void {
    $q = trim((string)($_GET['q'] ?? ''));
    if (strlen($q) < 2) json_list([]);
    $s = db()->prepare(
        "SELECT DISTINCT p.nome FROM produtos p JOIN empresas e ON e.id = p.empresa_id
         WHERE " . PUBLIC_WHERE . " AND p.nome LIKE ? LIMIT 8"
    );
    $s->execute(['%' . $q . '%']);
    json_list(array_column($s->fetchAll(), 'nome'));
}
