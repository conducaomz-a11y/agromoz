<?php
/** Perfis públicos — na app, o "agricultor/vendedor" é a EMPRESA do site. */

/** GET /farmers — lista pública de empresas (fornecedores).
 *  Filtros: ?type=agricultor|horticultor|... · ?q=texto · ?page= */
function route_farmers_list(): void {
    $page    = max(1, (int)($_GET['page'] ?? 1));
    $perPage = min(30, max(1, (int)($_GET['per_page'] ?? 15)));

    $where = ["e.status = 'ativo'"];
    $args  = [];
    if (!empty($_GET['type'])) { $where[] = 'e.tipo_perfil = ?'; $args[] = $_GET['type']; }
    if (!empty($_GET['q'])) {
        $where[] = '(e.nome_empresa LIKE ? OR e.descricao LIKE ?)';
        $like = '%' . $_GET['q'] . '%';
        array_push($args, $like, $like);
    }
    if (!empty($_GET['province'])) { $where[] = 'e.provincia = ?'; $args[] = $_GET['province']; }
    $whereSql = 'WHERE ' . implode(' AND ', $where);

    $pdo = db();
    $count = $pdo->prepare("SELECT COUNT(*) FROM empresas e $whereSql");
    $count->execute($args);
    $total = (int)$count->fetchColumn();

    $offset = ($page - 1) * $perPage;
    $q = $pdo->prepare(
        "SELECT e.* FROM empresas e $whereSql
         ORDER BY e.destaque DESC, e.id DESC LIMIT $perPage OFFSET $offset"
    );
    try {
        $q->execute($args);
        $rows = $q->fetchAll();
    } catch (Throwable $ex) {
        // coluna 'destaque' pode não existir nesta instalação
        $q = $pdo->prepare("SELECT e.* FROM empresas e $whereSql ORDER BY e.id DESC LIMIT $perPage OFFSET $offset");
        $q->execute($args);
        $rows = $q->fetchAll();
    }

    json_paginated(
        array_map('empresa_json', $rows),
        $page,
        max(1, (int)ceil($total / $perPage))
    );
}

/** GET /farmers/{id} — id da empresa. */
function route_farmer(string $id): void {
    $q = db()->prepare('SELECT * FROM empresas WHERE id = ?');
    $q->execute([$id]);
    $row = $q->fetch();
    if (!$row) json_error('Perfil não encontrado.', 404);
    json_out(['data' => empresa_json($row)]);
}

/** GET /farmers/{id}/reviews — app_reviews da empresa. */
function route_farmer_reviews(string $id): void {
    $q = db()->prepare(
        'SELECT r.*, u.name AS author_name, u.avatar AS author_avatar
         FROM app_reviews r JOIN users u ON u.id = r.author_id
         WHERE r.empresa_id = ? ORDER BY r.created_at DESC'
    );
    $q->execute([$id]);
    json_list(array_map(fn($r) => [
        'id' => (string)$r['id'],
        'author_name' => $r['author_name'],
        'author_avatar_url' => site_url($r['author_avatar']),
        'rating' => (float)$r['rating'],
        'comment' => $r['comment'],
        'created_at' => $r['created_at'],
    ], $q->fetchAll()));
}

/** POST /farmers/{id}/reviews — avaliar uma empresa {rating 1-5, comment?}. */
function route_farmer_review_create(string $id): void {
    $user = require_auth();

    $q = db()->prepare('SELECT id, user_id FROM empresas WHERE id = ?');
    $q->execute([$id]);
    $empresa = $q->fetch();
    if (!$empresa) json_error('Perfil não encontrado.', 404);
    if ((int)$empresa['user_id'] === (int)$user['id']) {
        json_error('Não podes avaliar a tua própria página.', 422);
    }

    $rating = (int)field('rating');
    if ($rating < 1 || $rating > 5) json_error('A avaliação deve ser de 1 a 5 estrelas.', 422);
    $comment = trim((string)field('comment')) ?: null;

    // Uma avaliação por utilizador — se já existe, actualiza-a.
    $q = db()->prepare('SELECT id FROM app_reviews WHERE empresa_id = ? AND author_id = ?');
    $q->execute([$id, $user['id']]);
    if ($rid = $q->fetchColumn()) {
        db()->prepare('UPDATE app_reviews SET rating = ?, comment = ?, created_at = NOW() WHERE id = ?')
            ->execute([$rating, $comment, $rid]);
    } else {
        db()->prepare('INSERT INTO app_reviews (empresa_id, author_id, rating, comment) VALUES (?,?,?,?)')
            ->execute([$id, $user['id'], $rating, $comment]);

        // Notifica o dono da empresa dentro da app.
        db()->prepare(
            'INSERT INTO app_notifications (user_id, title, body, type, target_id)
             VALUES (?, ?, ?, "review", ?)'
        )->execute([
            $empresa['user_id'],
            'Nova avaliação ⭐',
            $user['name'] . ' avaliou a tua página com ' . $rating . ' estrela' . ($rating > 1 ? 's' : '') . '.',
            $id,
        ]);
    }

    json_out(['message' => 'Obrigado pela tua avaliação!'], 201);
}
