<?php
/** Catálogo sobre as tabelas do site: produtos + empresas + categorias_negocio. */

const PRODUCT_SELECT =
    'SELECT p.*, cn.nome AS category_name,
            e.id AS e_id, e.nome_empresa, e.tipo_perfil,
            e.descricao AS e_descricao, e.provincia AS e_provincia,
            e.distrito AS e_distrito, e.telefone, e.whatsapp,
            e.email_contacto, e.logo, e.created_at AS e_created_at,
            e.user_id AS e_user_id
     FROM produtos p
     JOIN empresas e ON e.id = p.empresa_id
     LEFT JOIN categorias_negocio cn ON cn.id = p.categoria_id';

/** Só produtos activos de empresas activas nas listagens públicas. */
const PUBLIC_WHERE = "p.status = 'ativo' AND e.status = 'ativo'";

/** GET /products */
function route_products(): void {
    $viewer = optional_auth();
    $page    = max(1, (int)($_GET['page'] ?? 1));
    $perPage = min(50, max(1, (int)($_GET['per_page'] ?? 20)));

    $where = [PUBLIC_WHERE];
    $args  = [];

    if (!empty($_GET['q'])) {
        $where[] = '(p.nome LIKE ? OR p.descricao LIKE ?)';
        $like = '%' . $_GET['q'] . '%';
        array_push($args, $like, $like);
    }
    if (!empty($_GET['category_id'])) { $where[] = 'p.categoria_id = ?'; $args[] = $_GET['category_id']; }
    if (!empty($_GET['seller_id']))   { $where[] = 'e.id = ?';           $args[] = $_GET['seller_id']; }
    if (!empty($_GET['province'])) {
        // O site guarda variações ("Maputo", "Maputo província"...):
        // compara pela primeira palavra, sem distinguir maiúsculas.
        $first = strtolower(explode(' ', trim($_GET['province']))[0]);
        $where[] = 'LOWER(e.provincia) LIKE ?';
        $args[] = $first . '%';
    }
    if (!empty($_GET['district'])) {
        $where[] = 'LOWER(e.distrito) LIKE ?';
        $args[] = '%' . strtolower($_GET['district']) . '%';
    }
    if (isset($_GET['min_price']) && $_GET['min_price'] !== '') { $where[] = 'p.preco >= ?'; $args[] = (float)$_GET['min_price']; }
    if (isset($_GET['max_price']) && $_GET['max_price'] !== '') { $where[] = 'p.preco <= ?'; $args[] = (float)$_GET['max_price']; }
    // 'condition' não existe no site — parâmetro aceite e ignorado.

    $order = match ($_GET['sort'] ?? 'recent') {
        'price_asc'  => 'p.preco ASC',
        'price_desc' => 'p.preco DESC',
        default      => 'p.created_at DESC',
    };

    $whereSql = 'WHERE ' . implode(' AND ', $where);
    $pdo = db();

    $count = $pdo->prepare(
        "SELECT COUNT(*) FROM produtos p JOIN empresas e ON e.id = p.empresa_id $whereSql"
    );
    $count->execute($args);
    $total = (int)$count->fetchColumn();

    $offset = ($page - 1) * $perPage;
    $q = $pdo->prepare(PRODUCT_SELECT . " $whereSql ORDER BY $order LIMIT $perPage OFFSET $offset");
    $q->execute($args);

    $items = array_map(
        fn($row) => product_json($row, $viewer ? (int)$viewer['id'] : null),
        $q->fetchAll()
    );
    json_paginated($items, $page, (int)ceil($total / $perPage));
}

function route_products_featured(): void {
    simple_product_list('p.destaque = 1 ORDER BY p.created_at DESC');
}
function route_products_recommended(): void {
    simple_product_list('1 ORDER BY p.views DESC, p.created_at DESC');
}

function simple_product_list(string $whereOrder): void {
    $viewer = optional_auth();
    $q = db()->query(PRODUCT_SELECT . ' WHERE ' . PUBLIC_WHERE . " AND $whereOrder LIMIT 10");
    json_list(array_map(
        fn($row) => product_json($row, $viewer ? (int)$viewer['id'] : null),
        $q->fetchAll()
    ));
}

/** GET /products/{id} */
function route_product_detail(string $id): void {
    $viewer = optional_auth();
    $pdo = db();
    $pdo->prepare('UPDATE produtos SET views = views + 1 WHERE id = ?')->execute([$id]);
    $q = $pdo->prepare(PRODUCT_SELECT . ' WHERE p.id = ?');
    $q->execute([$id]);
    $row = $q->fetch();
    if (!$row) json_error('Produto não encontrado.', 404);
    json_out(['data' => product_json($row, $viewer ? (int)$viewer['id'] : null)]);
}

/** GET /products/{id}/related */
function route_products_related(string $id): void {
    $viewer = optional_auth();
    $q = db()->prepare(
        PRODUCT_SELECT . ' WHERE ' . PUBLIC_WHERE .
        ' AND p.categoria_id = (SELECT categoria_id FROM produtos WHERE id = ?)
          AND p.id <> ? ORDER BY p.created_at DESC LIMIT 10'
    );
    $q->execute([$id, $id]);
    json_list(array_map(
        fn($row) => product_json($row, $viewer ? (int)$viewer['id'] : null),
        $q->fetchAll()
    ));
}

/** DELETE /products/{id} — só o dono da empresa. */
function route_product_delete(string $id): void {
    $user = require_auth();
    $q = db()->prepare(
        'DELETE p FROM produtos p JOIN empresas e ON e.id = p.empresa_id
         WHERE p.id = ? AND e.user_id = ?'
    );
    $q->execute([$id, $user['id']]);
    if (!$q->rowCount()) json_error('Não tem permissão para esta acção.', 403);
    json_out(['message' => 'Anúncio removido.']);
}

/** GET /categories — categorias_negocio do site. */
function route_categories(): void {
    // ?type=agricultor → categorias desse tipo de perfil (para o wizard do negócio).
    // O nome da coluna/pivot varia entre instalações; tenta as variantes comuns
    // e cai para a lista completa se nenhuma existir.
    $type = trim((string)($_GET['type'] ?? ($_GET['tipo'] ?? '')));
    if ($type !== '') {
        foreach ([
            'SELECT cn.id, cn.nome, 0 AS product_count FROM categorias_negocio cn WHERE cn.tipo_perfil = ? ORDER BY cn.nome',
            'SELECT cn.id, cn.nome, 0 AS product_count FROM categorias_negocio cn WHERE cn.tipo = ? ORDER BY cn.nome',
            'SELECT cn.id, cn.nome, 0 AS product_count FROM categorias_negocio cn
               JOIN categoria_tipos ct ON ct.categoria_id = cn.id WHERE ct.tipo_perfil = ? ORDER BY cn.nome',
        ] as $sql) {
            try {
                $q = db()->prepare($sql);
                $q->execute([$type]);
                $rows = $q->fetchAll();
                if ($rows) {
                    json_list(array_map(fn($c) => [
                        'id' => (string)$c['id'], 'name' => $c['nome'],
                        'icon_url' => null, 'product_count' => 0,
                    ], $rows));
                }
            } catch (Throwable $e) { /* coluna não existe nesta instalação — tenta a próxima */ }
        }
        // sem correspondência: devolve todas (o utilizador escolhe na mesma)
    }
    $rows = db()->query(
        'SELECT cn.id, cn.nome,
            (SELECT COUNT(*) FROM produtos p JOIN empresas e ON e.id = p.empresa_id
             WHERE p.categoria_id = cn.id AND ' . PUBLIC_WHERE . ') AS product_count
         FROM categorias_negocio cn ORDER BY cn.nome'
    )->fetchAll();
    json_list(array_map(fn($c) => [
        'id' => (string)$c['id'],
        'name' => $c['nome'],
        'icon_url' => null, // o site usa classes CSS (bi-*), a app mostra ícone padrão
        'product_count' => (int)$c['product_count'],
    ], $rows));
}

/** GET /banners — tabela app_banners (gerida por si no phpMyAdmin ou admin). */
function route_banners(): void {
    $rows = db()->query('SELECT * FROM app_banners WHERE is_active = 1 ORDER BY id DESC')->fetchAll();
    json_list(array_map(fn($b) => [
        'id' => (string)$b['id'],
        'title' => $b['title'],
        'image_url' => site_url($b['image_url']),
        'target_url' => $b['target_url'],
        'product_id' => $b['product_id'] !== null ? (string)$b['product_id'] : null,
    ], $rows));
}

/** Favoritos → app_favorites (aponta para produtos do site). */
function route_favorites_list(): void {
    $user = require_auth();
    $q = db()->prepare(
        PRODUCT_SELECT . ' JOIN app_favorites f ON f.product_id = p.id
         WHERE f.user_id = ? ORDER BY f.created_at DESC'
    );
    $q->execute([$user['id']]);
    json_list(array_map(fn($row) => product_json($row, (int)$user['id']), $q->fetchAll()));
}

function route_favorite_add(string $productId): void {
    $user = require_auth();
    db()->prepare('INSERT IGNORE INTO app_favorites (user_id, product_id) VALUES (?, ?)')
        ->execute([$user['id'], $productId]);
    json_out(['message' => 'Adicionado aos favoritos.']);
}

function route_favorite_remove(string $productId): void {
    $user = require_auth();
    db()->prepare('DELETE FROM app_favorites WHERE user_id = ? AND product_id = ?')
        ->execute([$user['id'], $productId]);
    json_out(['message' => 'Removido dos favoritos.']);
}
