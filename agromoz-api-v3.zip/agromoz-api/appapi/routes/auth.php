<?php
/** Autenticação — MESMOS utilizadores do site (users.password é bcrypt).
 *  Verificação de conta por código de 6 dígitos no e-mail, igual ao site
 *  (colunas users.email_verified / verification_code / verification_expires). */

/** POST /login */
function route_login(): void {
    $identifier = trim((string)field('identifier'));
    $password   = (string)field('password');
    if ($identifier === '' || $password === '') json_error('Introduza as credenciais.', 422);

    $q = db()->prepare('SELECT * FROM users WHERE email = ? OR phone = ? LIMIT 1');
    $q->execute([$identifier, $identifier]);
    $user = $q->fetch();

    if (!$user || !password_verify($password, $user['password'])) {
        json_error('Credenciais inválidas.', 401);
    }
    if ($user['status'] === 'banned') json_error('Esta conta foi suspensa.', 403);
    if ($user['status'] !== 'active') json_error('Conta inactiva. Contacte o suporte.', 403);

    // E-mail por confirmar? Reenvia o código e avisa a app (igual ao site).
    if (array_key_exists('email_verified', $user) && !(int)$user['email_verified']) {
        send_new_code((int)$user['id'], $user['email'], $user['name']);
        json_out([
            'message' => 'Confirma o teu e-mail antes de entrar. Enviámos-te um código.',
            'needs_verification' => true,
            'identifier' => $user['email'],
        ], 403);
    }

    $tokens = issue_tokens((int)$user['id']);
    json_out($tokens + ['user' => account_json($user)]);
}

/** POST /register — cria o utilizador na MESMA tabela do site, por verificar. */
function route_register(): void {
    $name  = trim((string)field('name'));
    $email = strtolower(trim((string)field('email')));
    $phone = preg_replace('/\D+/', '', (string)field('phone'));
    $pass  = (string)field('password');
    $province = field('province');
    $wantsBusiness = (bool)field('wants_business', false);

    if (mb_strlen($name) < 3) json_error('O nome deve ter pelo menos 3 caracteres.', 422);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) json_error('E-mail inválido.', 422);
    if (strlen($pass) < 6) json_error('A palavra-passe deve ter pelo menos 6 caracteres.', 422);

    $pdo = db();
    $q = $pdo->prepare('SELECT id, email_verified, name FROM users WHERE email = ? LIMIT 1');
    $q->execute([$email]);
    $existente = $q->fetch();

    if ($existente) {
        // Conta criada mas nunca verificada — retoma a verificação (igual ao site).
        if (!(int)$existente['email_verified']) {
            send_new_code((int)$existente['id'], $email, $existente['name'] ?: $name);
            json_out([
                'message' => 'Esta conta já existe mas o e-mail ainda não foi confirmado. Enviámos um novo código.',
                'needs_verification' => true,
                'identifier' => $email,
            ]);
        }
        json_error('Este e-mail já está registado.', 422);
    }

    if ($phone !== '') {
        $q = $pdo->prepare('SELECT 1 FROM users WHERE phone = ?');
        $q->execute([$phone]);
        if ($q->fetchColumn()) json_error('Já existe uma conta com este telefone.', 422);
    }

    $code = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    $q = $pdo->prepare(
        'INSERT INTO users (name, email, phone, password, province, role, status,
                            email_verified, verification_code, verification_expires)
         VALUES (?, ?, ?, ?, ?, "user", "active", 0, ?, DATE_ADD(NOW(), INTERVAL 30 MINUTE))'
    );
    $q->execute([$name, $email, $phone, password_hash($pass, PASSWORD_DEFAULT), $province, $code]);

    $sent = send_verification_email($email, $name, $code);

    $resp = [
        'message' => $sent
            ? 'Conta criada! Enviámos um código de 6 dígitos para o teu e-mail.'
            : 'Conta criada, mas houve um problema a enviar o e-mail. Usa "Reenviar código".',
        'needs_verification' => true,
        'identifier' => $email,
        'wants_business' => $wantsBusiness,
    ];
    if (DEBUG_OTP) $resp['debug_code'] = $code; // apenas testes — desligar em produção!
    json_out($resp, 201);
}

/** POST /verify-email — confirma o código e ENTRA (devolve tokens + user). */
function route_verify_email(): void {
    $identifier = trim((string)field('identifier'));
    $code = trim((string)field('code'));
    if ($identifier === '' || $code === '') json_error('Introduza o código.', 422);

    $q = db()->prepare(
        'SELECT * FROM users
         WHERE (email = ? OR phone = ?) AND verification_code = ? AND verification_expires > NOW()
         LIMIT 1'
    );
    $q->execute([$identifier, $identifier, $code]);
    $user = $q->fetch();
    if (!$user) json_error('Código inválido ou expirado.', 422);

    db()->prepare(
        'UPDATE users SET email_verified = 1, verification_code = NULL, verification_expires = NULL
         WHERE id = ?'
    )->execute([$user['id']]);

    json_out(issue_tokens((int)$user['id']) + ['user' => account_json($user)]);
}

/** POST /resend-code — reenvia o código de verificação de conta. */
function route_resend_code(): void {
    $identifier = trim((string)field('identifier'));
    if ($identifier === '') json_error('Introduza o e-mail.', 422);

    $q = db()->prepare('SELECT id, email, name, email_verified FROM users WHERE email = ? OR phone = ? LIMIT 1');
    $q->execute([$identifier, $identifier]);
    $user = $q->fetch();
    if (!$user) json_error('Conta não encontrada.', 404);
    if ((int)$user['email_verified']) json_error('Esta conta já está verificada — podes entrar.', 422);

    $debug = send_new_code((int)$user['id'], $user['email'], $user['name']);
    $resp = ['message' => 'Código reenviado para o teu e-mail.'];
    if (DEBUG_OTP) $resp['debug_code'] = $debug;
    json_out($resp);
}

/** Gera, guarda e envia um novo código. Devolve o código (para DEBUG_OTP). */
function send_new_code(int $userId, string $email, string $name): string {
    $code = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    db()->prepare(
        'UPDATE users SET verification_code = ?, verification_expires = DATE_ADD(NOW(), INTERVAL 30 MINUTE)
         WHERE id = ?'
    )->execute([$code, $userId]);
    send_verification_email($email, $name ?: 'utilizador', $code);
    return $code;
}

/** POST /forgot-password — usa as colunas verification_code/expires do site. */
function route_forgot_password(): void {
    $identifier = trim((string)field('identifier'));
    if ($identifier === '') json_error('Introduza o e-mail ou telefone.', 422);

    $q = db()->prepare('SELECT id, email, name FROM users WHERE email = ? OR phone = ?');
    $q->execute([$identifier, $identifier]);
    $user = $q->fetch();
    if (!$user) json_error('Conta não encontrada.', 404);

    $code = str_pad((string)random_int(0, 999999), 6, '0', STR_PAD_LEFT);
    db()->prepare(
        'UPDATE users SET verification_code = ?, verification_expires = DATE_ADD(NOW(), INTERVAL 10 MINUTE)
         WHERE id = ?'
    )->execute([$code, $user['id']]);

    send_verification_email($user['email'], $user['name'], $code);

    $resp = ['message' => 'Código enviado para o teu e-mail.'];
    if (DEBUG_OTP) $resp['debug_code'] = $code; // remova em produção!
    json_out($resp);
}

/** POST /verify-otp (recuperação de senha) */
function route_verify_otp(): void {
    $identifier = trim((string)field('identifier'));
    $code = trim((string)field('code'));
    $q = db()->prepare(
        'SELECT id FROM users
         WHERE (email = ? OR phone = ?) AND verification_code = ? AND verification_expires > NOW()'
    );
    $q->execute([$identifier, $identifier, $code]);
    $id = $q->fetchColumn();
    if (!$id) json_error('Código inválido ou expirado.', 422);

    // Se veio uma senha nova, redefine-a já (fluxo "esqueci a senha" completo).
    $newPass = (string)field('new_password');
    if (strlen($newPass) >= 6) {
        db()->prepare('UPDATE users SET password = ? WHERE id = ?')
            ->execute([password_hash($newPass, PASSWORD_DEFAULT), $id]);
    }

    db()->prepare(
        'UPDATE users SET verification_code = NULL, verification_expires = NULL, email_verified = 1 WHERE id = ?'
    )->execute([$id]);
    json_out(['message' => 'Código verificado.']);
}

/** POST /refresh-token */
function route_refresh_token(): void {
    $refresh = (string)field('refresh_token');
    $q = db()->prepare('SELECT * FROM app_tokens WHERE refresh_token = ? AND refresh_expires_at > NOW()');
    $q->execute([$refresh]);
    $row = $q->fetch();
    if (!$row) json_error('Sessão expirada.', 401);
    db()->prepare('DELETE FROM app_tokens WHERE id = ?')->execute([$row['id']]);
    json_out(issue_tokens((int)$row['user_id']));
}

/** POST /logout */
function route_logout(): void {
    $token = bearer_token();
    if ($token) db()->prepare('DELETE FROM app_tokens WHERE access_token = ?')->execute([$token]);
    json_out(['message' => 'Sessão terminada.']);
}
