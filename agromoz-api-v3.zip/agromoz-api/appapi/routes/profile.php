<?php
/** Conta — tabela users do site. */

function route_profile_get(): void {
    $user = require_auth();
    json_out(['data' => account_json($user)]);
}

/** PUT/POST /profile — actualiza users; aceita multipart "avatar". */
function route_profile_update(): void {
    $user = require_auth();
    $avatarUrl = save_upload('avatar');

    $fields = [];
    $args = [];
    foreach (['name', 'email', 'phone', 'province', 'district', 'bio'] as $f) {
        $v = field($f, '__missing__');
        if ($v !== '__missing__') { $fields[] = "`$f` = ?"; $args[] = $v; }
    }
    if ($avatarUrl) { $fields[] = 'avatar = ?'; $args[] = $avatarUrl; }

    if ($fields) {
        $args[] = $user['id'];
        db()->prepare('UPDATE users SET ' . implode(', ', $fields) . ' WHERE id = ?')
            ->execute($args);
    }
    $q = db()->prepare('SELECT * FROM users WHERE id = ?');
    $q->execute([$user['id']]);
    json_out(['data' => account_json($q->fetch())]);
}

/** POST /profile/password — coluna users.password (bcrypt, igual ao site). */
function route_change_password(): void {
    $user = require_auth();
    $current = (string)field('current_password');
    $new = (string)field('new_password');
    if (strlen($new) < 6) json_error('A nova palavra-passe deve ter pelo menos 6 caracteres.', 422);
    if (!password_verify($current, $user['password'])) {
        json_error('A palavra-passe actual está incorrecta.', 422);
    }
    db()->prepare('UPDATE users SET password = ? WHERE id = ?')
        ->execute([password_hash($new, PASSWORD_DEFAULT), $user['id']]);
    json_out(['message' => 'Palavra-passe alterada.']);
}

/** GET /profile/listings — produtos das empresas do utilizador (todos os estados). */
function route_my_listings(): void {
    $user = require_auth();
    $q = db()->prepare(PRODUCT_SELECT . ' WHERE e.user_id = ? ORDER BY p.created_at DESC');
    $q->execute([$user['id']]);
    json_list(array_map(fn($row) => product_json($row, (int)$user['id']), $q->fetchAll()));
}
