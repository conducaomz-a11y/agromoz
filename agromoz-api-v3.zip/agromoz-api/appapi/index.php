<?php
/**
 * AgroMoz API — router principal (PHP puro, sem dependências).
 * Ponto de entrada de todos os pedidos /api/v1/...
 */

declare(strict_types=1);
error_reporting(E_ALL);
ini_set('display_errors', '0'); // erros nunca vão para o cliente

// CORS (inofensivo para a app móvel; útil se um dia houver painel web)
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Authorization, Content-Type');
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(204); exit; }

if (!file_exists(__DIR__ . '/config.php')) {
    http_response_code(500);
    header('Content-Type: application/json');
    echo json_encode(['message' => 'Falta o config.php — renomeie config.sample.php e preencha.']);
    exit;
}
require __DIR__ . '/config.php';
require __DIR__ . '/core/response.php';
require __DIR__ . '/core/db.php';
require __DIR__ . '/core/helpers.php';
require __DIR__ . '/core/auth.php';
require __DIR__ . '/core/mailer.php';
foreach (glob(__DIR__ . '/routes/*.php') as $f) require $f;

// ── Normaliza o caminho: tudo depois de /v1 ─────────────────────
$uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH) ?? '/';
$pos = strpos($uri, '/v1');
$path = $pos !== false ? substr($uri, $pos + 3) : $uri;
$path = '/' . trim($path, '/');
$method = $_SERVER['REQUEST_METHOD'];

// ── Tabela de rotas: [método, padrão, handler] ──────────────────
$routes = [
    // Auth
    ['POST',   '#^/login$#',            'route_login'],
    ['POST',   '#^/register$#',         'route_register'],
    ['POST',   '#^/forgot-password$#',  'route_forgot_password'],
    ['POST',   '#^/verify-otp$#',       'route_verify_otp'],
    ['POST',   '#^/verify-email$#',     'route_verify_email'],
    ['POST',   '#^/resend-code$#',      'route_resend_code'],
    ['POST',   '#^/refresh-token$#',    'route_refresh_token'],
    ['POST',   '#^/logout$#',           'route_logout'],

    // Catálogo
    ['GET',    '#^/products$#',                    'route_products'],
    ['GET',    '#^/products/featured$#',           'route_products_featured'],
    ['GET',    '#^/products/recommended$#',        'route_products_recommended'],
    ['GET',    '#^/products/([\w-]+)/related$#',   'route_products_related'],
    ['GET',    '#^/products/([\w-]+)$#',           'route_product_detail'],
    ['DELETE', '#^/products/([\w-]+)$#',           'route_product_delete'],
    ['GET',    '#^/categories$#',                  'route_categories'],
    ['GET',    '#^/banners$#',                     'route_banners'],

    // Conta
    ['GET',    '#^/profile$#',           'route_profile_get'],
    ['PUT',    '#^/profile$#',           'route_profile_update'],
    ['POST',   '#^/profile$#',           'route_profile_update'], // multipart via POST
    ['POST',   '#^/profile/password$#',  'route_change_password'],
    ['GET',    '#^/profile/listings$#',  'route_my_listings'],
    ['GET',    '#^/favorites$#',         'route_favorites_list'],
    ['POST',   '#^/favorites/([\w-]+)$#','route_favorite_add'],
    ['DELETE', '#^/favorites/([\w-]+)$#','route_favorite_remove'],

    // Artigos educativos (abrem DENTRO da app)
    ['GET',    '#^/articles$#',              'route_articles'],
    ['GET',    '#^/articles/categories$#',   'route_article_categories'],
    ['GET',    '#^/articles/([\w-]+)$#',     'route_article_detail'],

    // Fluxo profissional (empresa + produtos, mesmas tabelas do site)
    ['GET',    '#^/business$#',              'route_business_get'],
    ['POST',   '#^/business$#',              'route_business_create'],
    ['POST',   '#^/business/update$#',       'route_business_update'],
    ['GET',    '#^/business/stats$#',        'route_business_stats'],
    ['GET',    '#^/business/types$#',        'route_business_types'],
    ['GET',    '#^/business/products$#',     'route_business_products'],
    ['POST',   '#^/business/products$#',     'route_business_product_create'],
    ['POST',   '#^/business/products/([\w-]+)$#',              'route_business_product_update'],
    ['PATCH',  '#^/business/products/([\w-]+)/availability$#', 'route_business_product_availability'],

    // Perfis públicos + avaliações
    ['GET',    '#^/farmers$#',                    'route_farmers_list'],
    ['GET',    '#^/farmers/([\w-]+)$#',          'route_farmer'],
    ['GET',    '#^/farmers/([\w-]+)/reviews$#',  'route_farmer_reviews'],
    ['POST',   '#^/farmers/([\w-]+)/reviews$#',  'route_farmer_review_create'],

    // Mensagens
    ['GET',    '#^/messages$#',            'route_conversations'],
    ['GET',    '#^/messages/([\w-]+)$#',   'route_messages'],
    ['POST',   '#^/messages/([\w-]+)$#',   'route_message_send'],

    // Notificações + FCM
    ['GET',    '#^/notifications$#',                 'route_notifications'],
    ['PATCH',  '#^/notifications/([\w-]+)/read$#',   'route_notification_read'],
    ['POST',   '#^/notifications/read-all$#',        'route_notifications_read_all'],
    ['POST',   '#^/devices$#',                       'route_register_device'],

    // Pesquisa
    ['GET',    '#^/search$#',              'route_search'],
    ['GET',    '#^/search/suggestions$#',  'route_search_suggestions'],
];

foreach ($routes as [$m, $pattern, $handler]) {
    if ($m === $method && preg_match($pattern, $path, $matches)) {
        try {
            $handler(...array_slice($matches, 1));
        } catch (Throwable $e) {
            // Nunca expor detalhes internos; registar no log do servidor.
            error_log('AgroMoz API: ' . $e->getMessage());
            json_error('Ocorreu um erro no servidor. Tente novamente.', 500);
        }
        exit;
    }
}

json_error('Recurso não encontrado.', 404);
