<?php
/**
 * AgroMoz API — configuração (integrada com o site existente).
 * 1) Renomeie este ficheiro para config.php
 * 2) Use os dados da MESMA base de dados do site
 */

define('DB_HOST', 'localhost');
define('DB_NAME', 'usuario_agromoz');   // a base de dados DO SITE
define('DB_USER', 'usuario_agromoz');
define('DB_PASS', 'SENHA_AQUI');

// URL pública desta API (sem barra no fim)
define('BASE_URL', 'https://agromoz.com/appapi');

// URL do site — usada para completar caminhos de imagens
// guardados nas tabelas (ex.: "uploads/produtos/2026/07/x.jpg")
define('SITE_URL', 'https://agromoz.com');

// Validade dos tokens (segundos)
define('ACCESS_TOKEN_TTL', 60 * 60 * 24 * 7);    // 7 dias
define('REFRESH_TOKEN_TTL', 60 * 60 * 24 * 30);  // 30 dias

// Em true, /forgot-password devolve o código OTP na resposta (APENAS para testes!)
define('DEBUG_OTP', true);
