<?php
/** Helpers de resposta JSON no formato que a app Flutter espera. */

function json_out($payload, int $status = 200): void {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    exit;
}

function json_error(string $message, int $status = 400): void {
    json_out(['message' => $message], $status);
}

/** Lista simples: { "data": [...] } */
function json_list(array $items): void {
    json_out(['data' => $items]);
}

/** Lista paginada: { "data": [...], "meta": {...} } */
function json_paginated(array $items, int $page, int $lastPage): void {
    json_out([
        'data' => $items,
        'meta' => ['current_page' => $page, 'last_page' => max(1, $lastPage)],
    ]);
}
