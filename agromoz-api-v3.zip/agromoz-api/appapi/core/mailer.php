<?php
/**
 * Envio de e-mails da API — mesmo mecanismo do site.
 *
 * 1º tenta usar o mailer do site (includes/mailer.php → enviar_email_verificacao),
 *    já configurado com o SMTP/remetente que funciona hoje.
 * 2º fallback: mail() nativo do PHP (funciona no Hostgator/cPanel).
 */

/** Envia o código de 6 dígitos. Devolve true se o envio (aparentemente) correu bem. */
function send_verification_email(string $email, string $name, string $code): bool
{
    // ── Tentativa 1: reutilizar o mailer do site ─────────────────
    // A pasta appapi/ vive dentro de public_html, ao lado do site.
    $siteMailer = dirname(__DIR__, 2) . '/includes/mailer.php';
    if (is_file($siteMailer)) {
        try {
            require_once $siteMailer;
            if (function_exists('enviar_email_verificacao')) {
                $ok = enviar_email_verificacao($email, $name, $code);
                if ($ok) return true;
            }
        } catch (Throwable $e) {
            error_log('AgroMoz API mailer (site): ' . $e->getMessage());
        }
    }

    // ── Tentativa 2: mail() nativo ───────────────────────────────
    $subject = 'AgroMoz — o teu código de verificação';
    $html = '<div style="font-family:Arial,sans-serif;max-width:480px;margin:0 auto;'
        . 'border:1px solid #e5e7eb;border-radius:12px;overflow:hidden">'
        . '<div style="background:#2d7a3e;color:#fff;padding:18px 24px;font-size:18px;font-weight:bold">🌱 AgroMoz</div>'
        . '<div style="padding:24px">'
        . '<p>Olá, <strong>' . htmlspecialchars($name) . '</strong>!</p>'
        . '<p>O teu código de verificação é:</p>'
        . '<p style="font-size:32px;letter-spacing:8px;font-weight:bold;color:#2d7a3e;text-align:center">'
        . htmlspecialchars($code) . '</p>'
        . '<p style="color:#6b7280;font-size:13px">O código expira em 30 minutos. '
        . 'Se não foste tu a pedir, ignora este e-mail.</p>'
        . '</div></div>';

    $domain = parse_url(SITE_URL, PHP_URL_HOST) ?: 'agromoz.com';
    $headers = "MIME-Version: 1.0\r\n"
        . "Content-Type: text/html; charset=UTF-8\r\n"
        . "From: AgroMoz <no-reply@{$domain}>\r\n";

    try {
        return mail($email, '=?UTF-8?B?' . base64_encode($subject) . '?=', $html, $headers);
    } catch (Throwable $e) {
        error_log('AgroMoz API mailer (mail): ' . $e->getMessage());
        return false;
    }
}
