<?php
/** Utilitários partilhados — adaptados ao esquema do site AgroMoz. */

function input(): array {
    static $data = null;
    if ($data !== null) return $data;
    $raw = file_get_contents('php://input');
    $json = json_decode($raw, true);
    $data = is_array($json) ? $json : $_POST;
    return $data;
}

function field(string $key, $default = null) {
    $data = input();
    return isset($data[$key]) && $data[$key] !== '' ? $data[$key] : $default;
}

/** Converte caminho relativo do site ("uploads/...") em URL completo. */
function site_url(?string $path): ?string {
    if ($path === null || $path === '') return null;
    if (str_starts_with($path, 'http://') || str_starts_with($path, 'https://')) return $path;
    return SITE_URL . '/' . ltrim($path, '/');
}

/** tipo_perfil da empresa → role que a app conhece. */
function map_role(?string $tipoPerfil): string {
    return match ($tipoPerfil) {
        'vendedor_insumos' => 'supplier',
        'agricultor', 'horticultor', 'avicultor', 'cunicultor' => 'farmer',
        default => 'buyer',
    };
}

/**
 * JSON da CONTA (tabela users do site) no formato UserModel da app.
 * O role é derivado: se o utilizador tem empresa, usa o tipo_perfil dela.
 */
function account_json(array $u): array {
    $pdo = db();
    $e = $pdo->prepare('SELECT tipo_perfil FROM empresas WHERE user_id = ? LIMIT 1');
    $e->execute([$u['id']]);
    $tipo = $e->fetchColumn() ?: null;

    $stats = $pdo->prepare(
        'SELECT
           (SELECT COUNT(*) FROM produtos p JOIN empresas em ON em.id = p.empresa_id
             WHERE em.user_id = ?) AS product_count,
           (SELECT COUNT(*) FROM app_reviews r JOIN empresas em ON em.id = r.empresa_id
             WHERE em.user_id = ?) AS review_count,
           (SELECT COALESCE(AVG(r.rating),0) FROM app_reviews r JOIN empresas em ON em.id = r.empresa_id
             WHERE em.user_id = ?) AS rating'
    );
    $stats->execute([$u['id'], $u['id'], $u['id']]);
    $s = $stats->fetch() ?: ['product_count' => 0, 'review_count' => 0, 'rating' => 0];

    return [
        'id'            => (string)$u['id'],
        'name'          => $u['name'],
        'email'         => $u['email'] ?? null,
        'phone'         => $u['phone'] ?? null,
        'avatar_url'    => site_url($u['avatar'] ?? null),
        'province'      => $u['province'] ?? null,
        'district'      => $u['district'] ?? null,
        'bio'           => $u['bio'] ?? null,
        'role'          => $tipo ? map_role($tipo) : 'buyer',
        'rating'        => round((float)$s['rating'], 1),
        'review_count'  => (int)$s['review_count'],
        'product_count' => (int)$s['product_count'],
        'is_online'     => false,
        'member_since'  => $u['created_at'] ?? null,
    ];
}

/**
 * JSON de uma EMPRESA como "vendedor" (UserModel da app).
 * Na app, o perfil público de vendedor é a empresa do site.
 */
function empresa_json(array $e): array {
    $pdo = db();
    $stats = $pdo->prepare(
        'SELECT
           (SELECT COUNT(*) FROM produtos WHERE empresa_id = ? AND status = "ativo") AS product_count,
           (SELECT COUNT(*) FROM app_reviews WHERE empresa_id = ?) AS review_count,
           (SELECT COALESCE(AVG(rating),0) FROM app_reviews WHERE empresa_id = ?) AS rating'
    );
    $stats->execute([$e['id'], $e['id'], $e['id']]);
    $s = $stats->fetch() ?: ['product_count' => 0, 'review_count' => 0, 'rating' => 0];

    return [
        'id'            => (string)$e['id'],
        'name'          => $e['nome_empresa'],
        'email'         => $e['email_contacto'] ?: null,
        'phone'         => $e['telefone'] ?: ($e['whatsapp'] ?: null),
        'whatsapp'      => $e['whatsapp'] ?: ($e['telefone'] ?: null),
        'avatar_url'    => site_url($e['logo'] ?? null),
        'province'      => $e['provincia'] ?? null,
        'district'      => $e['distrito'] ?? null,
        'bio'           => $e['descricao'] ?? null,
        'type'          => $e['tipo_perfil'] ?? null,
        'cover_url'     => site_url($e['imagem_capa'] ?? null),
        'role'          => map_role($e['tipo_perfil'] ?? null),
        'rating'        => round((float)$s['rating'], 1),
        'review_count'  => (int)$s['review_count'],
        'product_count' => (int)$s['product_count'],
        'is_online'     => false,
        'member_since'  => $e['created_at'] ?? null,
    ];
}

/**
 * JSON de um produto (tabela produtos + empresa + categorias_negocio).
 * Espera as colunas aliased do PRODUCT_SELECT em routes/products.php.
 */
function product_json(array $p, ?int $viewerId = null): array {
    $pdo = db();
    $isFav = false;
    if ($viewerId) {
        $q = $pdo->prepare('SELECT 1 FROM app_favorites WHERE user_id = ? AND product_id = ?');
        $q->execute([$viewerId, $p['id']]);
        $isFav = (bool)$q->fetchColumn();
    }

    $seller = null;
    if (!empty($p['e_id'])) {
        $seller = empresa_json([
            'id'             => $p['e_id'],
            'nome_empresa'   => $p['nome_empresa'],
            'tipo_perfil'    => $p['tipo_perfil'],
            'descricao'      => $p['e_descricao'],
            'provincia'      => $p['e_provincia'],
            'distrito'       => $p['e_distrito'],
            'telefone'       => $p['telefone'],
            'whatsapp'       => $p['whatsapp'],
            'email_contacto' => $p['email_contacto'],
            'logo'           => $p['logo'],
            'created_at'     => $p['e_created_at'],
        ]);
    }

    $img = site_url($p['imagem'] ?? null);
    return [
        'id'                 => (string)$p['id'],
        'title'              => $p['nome'],
        'price'              => (float)($p['preco'] ?? 0),
        'description'        => $p['descricao'] ?? null,
        'images'             => $img ? [$img] : [],
        'category_id'        => isset($p['categoria_id']) ? (string)$p['categoria_id'] : null,
        'category_name'      => $p['category_name'] ?? null,
        'province'           => $p['e_provincia'] ?? null,
        'district'           => $p['e_distrito'] ?? null,
        'condition'          => null, // o site não guarda estado novo/usado
        'unit'               => $p['unidade'] ?? null,
        'quantity_available' => null,
        'is_available'       => ($p['disponibilidade'] ?? 'disponivel') !== 'indisponivel'
                                && ($p['status'] ?? 'ativo') === 'ativo',
        'is_featured'        => (bool)($p['destaque'] ?? 0),
        'is_favorite'        => $isFav,
        'seller'             => $seller,
        'created_at'         => $p['created_at'] ?? null,
        'view_count'         => (int)($p['views'] ?? 0),
    ];
}

/** Guarda imagem multipart e devolve URL público (pasta uploads/ da API). */
function save_upload(string $fileKey): ?string {
    if (empty($_FILES[$fileKey]) || $_FILES[$fileKey]['error'] !== UPLOAD_ERR_OK) return null;
    $f = $_FILES[$fileKey];
    if ($f['size'] > 5 * 1024 * 1024) json_error('Imagem demasiado grande (máx. 5 MB).', 422);

    $mime = mime_content_type($f['tmp_name']);
    $ext = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'][$mime] ?? null;
    if (!$ext) json_error('Formato de imagem não suportado (use JPG, PNG ou WEBP).', 422);

    $name = bin2hex(random_bytes(16)) . '.' . $ext;
    $dest = __DIR__ . '/../uploads/' . $name;
    if (!move_uploaded_file($f['tmp_name'], $dest)) {
        json_error('Falha ao guardar a imagem.', 500);
    }
    return BASE_URL . '/uploads/' . $name;
}

/** Gera um slug único numa tabela (igual ao gerar_slug_unico do site). */
function unique_slug(string $table, string $text, ?int $ignoreId = null): string {
    $base = strtolower(trim(preg_replace('/[^a-z0-9]+/i', '-', iconv('UTF-8', 'ASCII//TRANSLIT//IGNORE', $text) ?: $text), '-'));
    if ($base === '') $base = 'item';
    $slug = $base;
    $i = 1;
    while (true) {
        $sql = "SELECT 1 FROM `$table` WHERE slug = ?" . ($ignoreId ? ' AND id <> ?' : '');
        $q = db()->prepare($sql);
        $q->execute($ignoreId ? [$slug, $ignoreId] : [$slug]);
        if (!$q->fetchColumn()) return $slug;
        $slug = $base . '-' . (++$i);
    }
}

/** Como save_upload(), mas recebe o array do ficheiro directamente (galerias). */
function save_upload_array(array $f): ?string {
    if (empty($f['tmp_name']) || ($f['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) return null;
    if ($f['size'] > 5 * 1024 * 1024) return null;
    $mime = mime_content_type($f['tmp_name']);
    $ext = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp'][$mime] ?? null;
    if (!$ext) return null;
    $name = bin2hex(random_bytes(16)) . '.' . $ext;
    if (!move_uploaded_file($f['tmp_name'], __DIR__ . '/../uploads/' . $name)) return null;
    return BASE_URL . '/uploads/' . $name;
}
