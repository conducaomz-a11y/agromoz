<?php
/** Autenticação Bearer sobre a tabela users DO SITE + app_tokens. */

function bearer_token(): ?string {
    $h = $_SERVER['HTTP_AUTHORIZATION'] ?? ($_SERVER['REDIRECT_HTTP_AUTHORIZATION'] ?? '');
    if (preg_match('/Bearer\s+(\S+)/i', $h, $m)) return $m[1];
    return null;
}

function optional_auth(): ?array {
    $token = bearer_token();
    if (!$token) return null;
    $q = db()->prepare(
        'SELECT u.* FROM app_tokens t
         JOIN users u ON u.id = t.user_id
         WHERE t.access_token = ? AND t.access_expires_at > NOW() AND u.status = "active"'
    );
    $q->execute([$token]);
    return $q->fetch() ?: null;
}

function require_auth(): array {
    $user = optional_auth();
    if (!$user) json_error('Sessão expirada. Inicie sessão novamente.', 401);
    return $user;
}

function issue_tokens(int $userId): array {
    $access  = bin2hex(random_bytes(32));
    $refresh = bin2hex(random_bytes(32));
    $q = db()->prepare(
        'INSERT INTO app_tokens (user_id, access_token, refresh_token, access_expires_at, refresh_expires_at)
         VALUES (?, ?, ?, DATE_ADD(NOW(), INTERVAL ? SECOND), DATE_ADD(NOW(), INTERVAL ? SECOND))'
    );
    $q->execute([$userId, $access, $refresh, ACCESS_TOKEN_TTL, REFRESH_TOKEN_TTL]);
    return ['access_token' => $access, 'refresh_token' => $refresh];
}
